export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Hello 👋</h1>
      <p>Your app is running successfully.</p>
    </main>
  );
}
